<?php
# protected and only access from localhost & local network (see .htaccess)
phpinfo(); ?>
