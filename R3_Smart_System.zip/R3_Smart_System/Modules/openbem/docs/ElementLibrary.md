# Moved

Moved to OpenEnergyMonitor Learn

[https://learn.openenergymonitor.org/sustainable-energy/building-energy-model/ElementLibrary](https://learn.openenergymonitor.org/sustainable-energy/building-energy-model/ElementLibrary)
