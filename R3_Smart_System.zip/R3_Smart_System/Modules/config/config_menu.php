<?php

    $menu_dropdown_config[] = array('name'=> "EmonHub", 'icon'=>'icon-bullhorn', 'path'=>"config/view" , 'session'=>"write", 'order' => 8 );

