<?php
    
    $menu_left[] = array(
        'id'=>"app_menu",
        'name'=>"Apps", 
        'path'=>"app/view" , 
        'session'=>"write", 
        'order' => 5,
        'icon'=>'icon-leaf icon-white'
    );
    
    

